import mysql.connector
from mysql.connector import Error

# --- Configuración de la conexión a la base de datos ---
db_config = {
    'host': '192.168.1.139',
    'user': 'Casino',
    'password': 'casino123',
    'database': 'casinodb',
    'port': 3306
}

connection = None

try:
    # Intenta establecer la conexión
    connection = mysql.connector.connect(**db_config)

    if connection.is_connected():
        print(f"✅ Conexión exitosa a la base de datos '{db_config['database']}'")
        
        cursor = connection.cursor()

        # --- CONSULTA ACTUALIZADA CON LOS NOMBRES DE TU TABLA ---
        # Se asume que la tabla se llama 'usuarios'. Si no es así, cámbiala.
        query = "SELECT usuario, saldo FROM usuarios;"
        
        print(f"\nEjecutando consulta: '{query}'")
        cursor.execute(query)

        # Obtiene TODOS los resultados de la consulta
        results = cursor.fetchall()

        # Verifica si se encontraron resultados
        if results:
            print("\n--- Resultados Encontrados ---")
            # Itera sobre los resultados e imprímelos
            for row in results:
                # row[0] es la primera columna (usuario)
                # row[1] es la segunda columna (saldo)
                print(f"👤 Usuario: {row[0]}, 💰 Saldo: {row[1]}")
            print("----------------------------")
        else:
            print("\n⚠️ No se encontraron usuarios en la tabla.")

except Error as e:
    # Manejo de errores de SQL o de conexión
    print(f"❌ Error al ejecutar la consulta: {e}")

finally:
    # Cierra la conexión de forma segura
    if connection is not None and connection.is_connected():
        cursor.close()
        connection.close()
        print("\n🔌 La conexión a la base de datos ha sido cerrada.")