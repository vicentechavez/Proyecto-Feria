# registro_main.py
# Aplicación dedicada exclusivamente al registro y administración de personas.
# Muestra la cámara en vivo para facilitar el encuadre.

import tkinter as tk
from tkinter import ttk, messagebox
import cv2
import time
from PIL import Image, ImageTk

# Importar nuestros módulos personalizados
import config
from database_handler import DatabaseHandler
import face_processor
import gui_manager

class RegistrationApplication:
    """
    Una aplicación de Tkinter diseñada únicamente para el registro de personas.
    Muestra la cámara en vivo para facilitar el encuadre.
    """
    def __init__(self, root):
        self.root = root
        self.root.title("Ojo Digital - Módulo de Registro")
        self.root.geometry("800x600")
        self.root.minsize(700, 500)
        self.root.configure(bg=config.COLORES["fondo_principal"])

        try:
            self.db_handler = DatabaseHandler(config.DB_CONFIG)
        except Exception as e:
            messagebox.showerror("Error Crítico de Base de Datos", f"No se pudo conectar a MySQL.\nError: {e}")
            self.root.destroy()
            return

        self.cap = None
        self.configurar_estilos()
        self.crear_widgets()
        
        # --- NUEVO: Variables para el control de actualizaciones en tiempo real ---
        self.admin_panel = None # Guardará una referencia al panel de admin si está abierto.
        self.last_update_timestamp = self.db_handler.get_system_update_timestamp() # Guarda la hora de la última actualización.
        
        # Iniciar la cámara al arrancar la aplicación
        self.iniciar_camara()

        # --- NUEVO: Iniciar el bucle de comprobación de actualizaciones ---
        self.check_for_updates_loop()

        self.root.protocol("WM_DELETE_WINDOW", self.cerrar_aplicacion)

    def configurar_estilos(self):
        """Configura los estilos ttk para la aplicación."""
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TFrame', background=config.COLORES["fondo_principal"])
        style.configure('TLabel', font=config.FONT_PRINCIPAL, background=config.COLORES["fondo_principal"], foreground=config.COLORES["texto_titulo"])
        
        style.configure('Blue.TButton', font=config.FONT_TITULO, padding=15, background=config.COLORES["boton_normal_bg"], foreground=config.COLORES["boton_normal_fg"], borderwidth=0, relief='flat')
        style.map('Blue.TButton', background=[('active', config.COLORES["boton_activo_bg"])])

        style.configure('Green.TButton', font=config.FONT_TITULO, padding=15, background=config.COLORES["boton_verde_bg"], foreground=config.COLORES["boton_verde_fg"], borderwidth=0, relief='flat')
        style.map('Green.TButton', background=[('active', config.COLORES["boton_verde_activo_bg"])])

        s_cfg = config.STYLE_CONFIG_VENTANA_SECUNDARIA
        style.configure(s_cfg['label_style'], background=s_cfg['bg'], foreground='white', font=config.FONT_PRINCIPAL)
        style.configure(s_cfg['frame_style'], background=s_cfg['bg'])
        style.configure(s_cfg['entry_style'], fieldbackground=s_cfg['bg'], foreground='white', insertcolor='white', bordercolor=config.COLORES["borde_widget"])
        style.map(s_cfg['combobox_style'], fieldbackground=[('readonly', s_cfg['bg'])], selectbackground=[('readonly', '#3c3c3c')], selectforeground=[('readonly', 'white')], foreground=[('readonly', 'white')])
        style.configure(s_cfg['combobox_style'], bordercolor=config.COLORES["borde_widget"])


    def crear_widgets(self):
        """Crea los widgets principales de la interfaz de registro."""
        self.root.grid_columnconfigure(0, weight=2)
        self.root.grid_columnconfigure(1, weight=1)
        self.root.grid_rowconfigure(0, weight=1)

        video_frame = ttk.Frame(self.root, padding=10)
        video_frame.grid(row=0, column=0, sticky="nsew")
        self.video_label = tk.Label(video_frame, bg=config.COLORES["fondo_label_video"])
        self.video_label.pack(expand=True, fill=tk.BOTH)

        main_frame = ttk.Frame(self.root, padding=20)
        main_frame.grid(row=0, column=1, sticky="nsew")

        app_title = ttk.Label(main_frame, text="Módulo de Registro", font=config.FONT_TITULO_APP)
        app_title.pack(pady=(20, 30))

        btn_registrar = ttk.Button(main_frame, text="Registrar Nueva Persona", command=self.show_registration_view, style='Green.TButton')
        btn_registrar.pack(fill=tk.X, pady=10, ipady=10)

        btn_admin = ttk.Button(main_frame, text="Administrar Registros", command=self.show_admin_panel_view, style='Blue.TButton')
        btn_admin.pack(fill=tk.X, pady=10, ipady=10)

    # --- NUEVO: Bucle que comprueba actualizaciones en la BD ---
    def check_for_updates_loop(self):
        """Comprueba si la base de datos ha sido actualizada por otro proceso."""
        try:
            current_timestamp = self.db_handler.get_system_update_timestamp()
            
            if self.last_update_timestamp != current_timestamp:
                print("🔄 Se detectó una actualización en la base de datos. Recargando...")
                self.last_update_timestamp = current_timestamp
                
                if self.admin_panel and self.admin_panel.winfo_exists():
                    self.admin_panel.refresh_data()

        except Exception as e:
            print(f"Error al comprobar actualizaciones: {e}")
        
        self.root.after(2000, self.check_for_updates_loop)

    def iniciar_camara(self):
        """Inicia la captura de la cámara y el bucle de actualización de video."""
        self.cap = None
        for i in range(3):
            cap_test = cv2.VideoCapture(i)
            if cap_test.isOpened():
                ret, _ = cap_test.read()
                if ret:
                    self.cap = cap_test
                    print(f"Cámara funcional encontrada en el índice {i}")
                    break
            cap_test.release()
        
        if not self.cap:
            messagebox.showerror("Error de Cámara", "No se pudo encontrar ninguna cámara funcional.")
            return

        self.actualizar_video_loop()

    def actualizar_video_loop(self):
        """Lee un frame de la cámara y lo muestra en la UI."""
        if self.cap and self.cap.isOpened():
            ret, frame = self.cap.read()
            if ret:
                frame_flipped = cv2.flip(frame, 1)
                self.mostrar_frame_en_ui(frame_flipped)
            self.root.after(15, self.actualizar_video_loop)

    def mostrar_frame_en_ui(self, frame):
        """Convierte un frame de OpenCV a un formato compatible con Tkinter y lo muestra."""
        try:
            h, w, _ = frame.shape
            label_w, label_h = self.video_label.winfo_width(), self.video_label.winfo_height()
            if label_h <= 1 or label_w <= 1: return
            
            scale = min(label_w / w, label_h / h)
            resized = cv2.resize(frame, (int(w * scale), int(h * scale)))
            img = ImageTk.PhotoImage(image=Image.fromarray(cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)))
            self.video_label.imgtk = img
            self.video_label.configure(image=img)
        except Exception as e:
            print(f"Error al mostrar frame: {e}")

    def show_registration_view(self):
        """Muestra la ventana de registro, usando la cámara que ya está activa."""
        if not self.cap or not self.cap.isOpened():
            messagebox.showerror("Error de Cámara", "La cámara no está activa. Intente reiniciar la aplicación.")
            return
        
        gui_manager.show_registration_window(
            self.root, 
            self.db_handler, 
            self._get_face_for_registration, 
            on_success_callback=None,
            style_config=config.STYLE_CONFIG_VENTANA_SECUNDARIA
        )

    def _get_face_for_registration(self, get_frame_only=False):
        """Captura un frame de la cámara ya activa para el proceso de registro."""
        if not self.cap or not self.cap.isOpened():
            return (False, None) if get_frame_only else (None, None)
        
        ret, frame = self.cap.read()
        if not ret:
            return (False, None) if get_frame_only else (None, None)

        frame_flipped = cv2.flip(frame, 1)

        if get_frame_only:
            return ret, frame_flipped
        else:
            return face_processor.extract_face_encoding(frame_flipped)

    def show_admin_login_view(self):
        """Muestra la ventana de login para el panel de administración."""
        gui_manager.show_admin_login_window(self.root, self.show_admin_panel_view)

    def show_admin_panel_view(self):
        """Muestra el panel de administración."""
        # --- MODIFICADO: Ahora guardamos la referencia a la ventana del panel ---
        self.admin_panel = gui_manager.show_admin_panel_window(
            self.root, 
            self.db_handler, 
            on_data_changed_callback=None, 
            style_config=config.STYLE_CONFIG_VENTANA_SECUNDARIA
        )

    def cerrar_aplicacion(self):
        """Cierra la aplicación de forma segura."""
        if messagebox.askokcancel("Salir", "¿Estás seguro de que quieres salir?"):
            print("Cerrando aplicación de registro...")
            if self.cap:
                self.cap.release()
            self.db_handler.close()
            self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = RegistrationApplication(root)
    root.mainloop()
