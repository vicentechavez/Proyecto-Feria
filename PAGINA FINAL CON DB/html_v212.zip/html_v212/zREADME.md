# 🚀 Ojo Digital - Plataforma de Vigilancia Inteligente

¡Bienvenido a Ojo Digital! Este proyecto es una simulación completa y funcional de un sitio web para un servicio de vigilancia inteligente. Ha sido desarrollado con un enfoque en la robustez, la experiencia de usuario y las buenas prácticas de código.

## ✨ Características Principales

* **Sistema de Autenticación Completo:** Registro, inicio de sesión y cierre de sesión de usuarios.
* **Restablecimiento de Contraseña Seguro:** Flujo de recuperación de cuenta a través de un token simulado.
* **Backend Robusto con PHP:** Una API RESTful gestiona todas las interacciones con la base de datos.
* **Interfaz Dinámica con JavaScript:** Notificaciones en tiempo real, modales interactivos y lógica de formularios del lado del cliente.
* **Diseño Moderno y Responsivo:** La interfaz se adapta perfectamente a dispositivos móviles, tablets y de escritorio.
* **Simulación de Pagos:** Flujo de contratación de planes con una pasarela de pago simulada.

## 🛠️ Tecnologías Utilizadas

* **Frontend:** HTML5, CSS3 (con variables y Flexbox), JavaScript (ES6+).
* **Backend:** PHP 8.
* **Base de Datos:** MySQL (MariaDB).
* **Servidor Local:** XAMPP (Apache).

## ⚙️ Pasos para la Instalación

Sigue estas instrucciones en orden para una configuración exitosa en tu entorno de desarrollo local.

### 1. 📦 Requisitos Previos

Necesitas un servidor local que soporte Apache, MySQL y PHP. La opción más sencilla es **XAMPP**.

* **Enlace de Descarga:** 👉 [Descargar XAMPP](https://www.apachefriends.org/es/index.html)

### 2. 🗂️ Configuración del Proyecto

1.  **Instala XAMPP** con las opciones por defecto.
2.  Navega a la carpeta de instalación de XAMPP (normalmente `C:\xampp` en Windows).
3.  Copia la carpeta completa de tu proyecto (`html_v1.3_MYSQL`) y pégala dentro de la subcarpeta `htdocs`.
    * La ruta final debería ser: `C:\xampp\htdocs\html_v1.3_MYSQL\`

### 3. 🖥️ Iniciar el Servidor Local

1.  Abre el **Panel de Control de XAMPP**.
2.  Inicia los dos servicios requeridos:
    * Haz clic en **Start** junto a **Apache**.
    * Haz clic en **Start** junto a **MySQL**.
3.  Ambos módulos deben mostrarse con un fondo verde, indicando que están activos.

### 4. 🗃️ Crear y Configurar la Base de Datos

1.  Abre tu navegador y ve a `http://localhost/phpmyadmin/`.

2.  **Paso A: Crear la Base de Datos**
    * En el menú izquierdo, haz clic en **"Nueva"**.
    * **Nombre de la base de datos:** Escribe `ojodigital` (exactamente, en minúsculas).
    * **Cotejamiento:** Selecciona `utf8mb4_general_ci`.
    * Haz clic en **"Crear"**.

3.  **Paso B: Crear las Tablas**
    * Selecciona la base de datos `ojodigital` en el menú izquierdo.
    * Ve a la pestaña **"SQL"**.
    * Copia y pega el siguiente código completo en el área de texto:

    ```sql
    -- Tabla para almacenar los usuarios registrados
    CREATE TABLE `users` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `email` varchar(255) NOT NULL,
      `password` varchar(255) NOT NULL,
      `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
      PRIMARY KEY (`id`),
      UNIQUE KEY `email` (`email`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

    -- Tabla para almacenar los mensajes del formulario de contacto
    CREATE TABLE `messages` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `name` varchar(255) NOT NULL,
      `email` varchar(255) NOT NULL,
      `message` text NOT NULL,
      `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

    -- Tabla para gestionar las solicitudes de restablecimiento de contraseña
    CREATE TABLE `password_resets` (
      `email` varchar(255) NOT NULL,
      `token` varchar(255) NOT NULL,
      `expires_at` timestamp NOT NULL,
      PRIMARY KEY (`email`),
      KEY `token_index` (`token`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
    ```
    * Haz clic en **"Continuar"** para ejecutar la consulta. Deberías ver un mensaje de éxito.

### 5. ▶️ Ejecutar el Proyecto

Con la configuración completa, solo necesitas:
1.  Verificar que Apache y MySQL sigan corriendo.
2.  Abrir tu navegador web.
3.  Ir a la dirección que coincide con el nombre de tu carpeta:
    `http://localhost/html_v1.3_MYSQL/`

¡Y listo! La página de inicio de Ojo Digital debería cargarse y ser 100% funcional.

### 📂 Estructura del Proyecto


/html_v1.3_MYSQL/
|
|-- assets/
|   |-- css/         # Hojas de estilo
|   |-- img/         # Imágenes y logos
|   |-- js/          # Scripts de JavaScript
|   |-- api/
|       |-- api.php  # Lógica del backend
|
|-- index.html       # Página de inicio
|-- contacto.html
|-- galeria.html
|-- (y demás archivos .html)
|
|-- zREADME.md       # Este archivo


### 🔍 Solución de Problemas Comunes

* **Error "No se puede conectar con la base de datos":**
    * Asegúrate de que MySQL esté corriendo en XAMPP.
    * Verifica que el nombre de la base de datos sea `ojodigital`.
    * El archivo `api.php` asume que la contraseña del usuario `root` de MySQL está vacía. Si has configurado una, debes actualizarla en la constante `DB_PASS` dentro de `api.php`.

* **Apache no se inicia:**
    * Este problema suele ser por un conflicto de puertos (normalmente el puerto 80).
    * En XAMPP, ve a `Config > Apache (httpd.conf)` y cambia la línea `Listen 80` a `Listen 8080`. Guarda el archivo y reinicia Apache. Ahora podrás acceder al proyecto desde `http://localhost:8080/html_v1.3_MYSQL/`.
