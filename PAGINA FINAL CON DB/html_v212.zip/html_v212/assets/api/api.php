<?php
/**
 * api.php
 *
 * API RESTful para gestionar usuarios, mensajes y restablecimiento de contraseñas.
 * Versión completa y corregida con todas las funciones implementadas.
 */

// ====================================================== //
// ||              1. CONFIGURACIÓN INICIAL            || //
// ====================================================== //

define('DEBUG_MODE', true);
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'ojodigital');
define('PASSWORD_MIN_LENGTH', 8);

if (DEBUG_MODE) {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(0);
}
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ====================================================== //
// ||                2. FUNCIÓN DE RESPUESTA             || //
// ====================================================== //

function sendJsonResponse(bool $success, string $message, ?array $data = null, int $statusCode = 200): void
{
    http_response_code($statusCode);
    $response = ['success' => $success, 'message' => $message];
    if ($data !== null) {
        $response['data'] = $data;
    }
    echo json_encode($response);
    exit();
}

// ====================================================== //
// ||               3. EJECUCIÓN PRINCIPAL             || //
// ====================================================== //

try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $conn->set_charset("utf8mb4");
} catch (mysqli_sql_exception $e) {
    $errorMessage = DEBUG_MODE ? "Error de conexión a la BD: " . $e->getMessage() : 'Error de servicio.';
    sendJsonResponse(false, $errorMessage, null, 503);
}

$data = json_decode(file_get_contents("php://input"));
if (json_last_error() !== JSON_ERROR_NONE && $_SERVER['REQUEST_METHOD'] === 'POST') {
    sendJsonResponse(false, 'Error en el formato JSON.', null, 400);
}

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'register':
        handleRegister($conn, $data);
        break;
    case 'login':
        handleLogin($conn, $data);
        break;
    case 'contact':
        handleContact($conn, $data);
        break;
    case 'request-reset':
        handlePasswordRequest($conn, $data);
        break;
    case 'reset-password':
        handlePasswordReset($conn, $data);
        break;
    default:
        sendJsonResponse(false, 'Acción no válida.', null, 404);
        break;
}

$conn->close();

// ====================================================== //
// ||          4. LÓGICA DE LOS ENDPOINTS (HANDLERS)   || //
// ====================================================== //

function handleRegister(mysqli $conn, ?object $data): void {
    if (empty($data->email) || empty($data->password)) { sendJsonResponse(false, 'El correo y la contraseña son obligatorios.', null, 400); }
    if (!filter_var($data->email, FILTER_VALIDATE_EMAIL)) { sendJsonResponse(false, 'El formato del correo electrónico no es válido.', null, 400); }
    if (strlen($data->password) < PASSWORD_MIN_LENGTH) { sendJsonResponse(false, 'La contraseña debe tener al menos ' . PASSWORD_MIN_LENGTH . ' caracteres.', null, 400); }
    
    $email = $data->email;
    $password_hash = password_hash($data->password, PASSWORD_BCRYPT);
    
    $stmt_check = $conn->prepare("SELECT email FROM users WHERE email = ?");
    $stmt_check->bind_param("s", $email);
    $stmt_check->execute();
    if ($stmt_check->get_result()->num_rows > 0) { sendJsonResponse(false, 'El correo electrónico ya está registrado.', null, 409); }
    $stmt_check->close();
    
    $stmt_insert = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
    $stmt_insert->bind_param("ss", $email, $password_hash);
    
    if ($stmt_insert->execute()) { 
        sendJsonResponse(true, '¡Registro exitoso! Iniciando sesión...', ['email' => $email]);
    } else { 
        sendJsonResponse(false, 'Error al registrar el usuario.', null, 500); 
    }
    $stmt_insert->close();
}

function handleLogin(mysqli $conn, ?object $data): void {
    if (empty($data->email) || empty($data->password)) { sendJsonResponse(false, 'El correo y la contraseña son obligatorios.', null, 400); }
    $email = $data->email;
    $stmt = $conn->prepare("SELECT email, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($user = $result->fetch_assoc()) {
        if (password_verify($data->password, $user['password'])) { 
            sendJsonResponse(true, 'Inicio de sesión exitoso.', ['email' => $user['email']]); 
        } else { 
            sendJsonResponse(false, 'La contraseña es incorrecta.', null, 401); 
        }
    } else { 
        sendJsonResponse(false, 'El correo electrónico no está registrado.', null, 401); 
    }
    $stmt->close();
}

function handleContact(mysqli $conn, ?object $data): void {
    if (empty($data->name) || empty($data->email) || empty($data->message)) { sendJsonResponse(false, 'Todos los campos son obligatorios.', null, 400); }
    if (!filter_var($data->email, FILTER_VALIDATE_EMAIL)) { sendJsonResponse(false, 'El formato del correo no es válido.', null, 400); }
    $stmt = $conn->prepare("INSERT INTO messages (name, email, message) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $data->name, $data->email, $data->message);
    if ($stmt->execute()) { sendJsonResponse(true, '¡Mensaje enviado! Gracias por contactarnos.'); } else { sendJsonResponse(false, 'Error al enviar el mensaje.', null, 500); }
    $stmt->close();
}

function handlePasswordRequest(mysqli $conn, ?object $data): void {
    if (empty($data->email) || !filter_var($data->email, FILTER_VALIDATE_EMAIL)) { sendJsonResponse(false, 'Por favor, introduce un correo electrónico válido.', null, 400); }
    $email = trim($data->email);
    try {
        $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows === 0) {
            sendJsonResponse(true, 'Si existe una cuenta con ese correo, recibirás instrucciones.');
            return;
        }
        $token = bin2hex(random_bytes(32));
        $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        $conn->begin_transaction();
        $stmt_delete = $conn->prepare("DELETE FROM password_resets WHERE email = ?");
        $stmt_delete->bind_param("s", $email);
        $stmt_delete->execute();
        $stmt_insert = $conn->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)");
        $stmt_insert->bind_param("sss", $email, $token, $expires_at);
        $stmt_insert->execute();
        $conn->commit();
        
        sendJsonResponse(true, 'Token generado.', ['token' => $token]);
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        $errorMessage = DEBUG_MODE ? "Error de BD [req]: " . $e->getMessage() : 'Error interno.';
        sendJsonResponse(false, $errorMessage, null, 500);
    }
}

function handlePasswordReset(mysqli $conn, ?object $data): void
{
    if (empty($data->token) || empty($data->new_password) || empty($data->confirm_password)) {
        sendJsonResponse(false, 'Error 400: Faltan datos en la solicitud (token o contraseñas).', null, 400);
        return;
    }
    if ($data->new_password !== $data->confirm_password) {
        sendJsonResponse(false, 'Error: Las contraseñas no coinciden.', null, 400);
        return;
    }
    if (strlen($data->new_password) < PASSWORD_MIN_LENGTH) {
        sendJsonResponse(false, 'La nueva contraseña debe tener al menos ' . PASSWORD_MIN_LENGTH . ' caracteres.', null, 400);
        return;
    }
    
    $token = $data->token;
    $new_password_hash = password_hash($data->new_password, PASSWORD_BCRYPT);
    $current_time = date('Y-m-d H:i:s');
    
    try {
        $stmt = $conn->prepare("SELECT email FROM password_resets WHERE token = ? AND expires_at > ?");
        $stmt->bind_param("ss", $token, $current_time);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            sendJsonResponse(false, 'Error 400: El token de restablecimiento no es válido o ha expirado.', null, 400);
            return;
        }
        
        $row = $result->fetch_assoc();
        $email = $row['email'];
        
        $conn->begin_transaction();
        $stmt_update = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
        $stmt_update->bind_param("ss", $new_password_hash, $email);
        $stmt_update->execute();
        $stmt_delete = $conn->prepare("DELETE FROM password_resets WHERE email = ?");
        $stmt_delete->bind_param("s", $email);
        $stmt_delete->execute();
        $conn->commit();
        
        sendJsonResponse(true, 'Tu contraseña ha sido actualizada exitosamente.');
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
        $errorMessage = DEBUG_MODE ? "Error de BD [reset]: " . $e->getMessage() : 'Error interno.';
        sendJsonResponse(false, $errorMessage, null, 500);
    }
}
