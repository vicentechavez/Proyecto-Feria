"use strict";

async function handleFormSubmit(action, data, onSuccess) {
    try {
        // Define los encabezados que quieres enviar
        const headers = {
            'Content-Type': 'application/json',
            // AÑADE ESTA LÍNEA para saltar la advertencia de ngrok
            'ngrok-skip-browser-warning': 'true' 
        };

        const response = await fetch(`${API_URL}?action=${action}`, {
            method: 'POST',
            // Usa la variable de encabezados aquí
            headers: headers, 
            body: JSON.stringify(data)
        });

        const result = await response.json();

        if (response.ok) {
            if (onSuccess) {
                onSuccess(result);
            }
        } else {
            showNotification(result.message || `Error del servidor: ${response.status}`, 'error');
        }
    } catch (error) {
        console.error('Error en handleFormSubmit:', error);
        showNotification('Error de conexión o del servidor.', 'error');
    }
}

document.addEventListener('DOMContentLoaded', () => {

    // ====================================================== //
    // ||                   UTILIDADES                     || //
    // ====================================================== //

    const API_URL = '/html_v212/assets/api/api.php';

    const showNotification = (message, type = 'success', duration = 4000) => {
        const container = document.getElementById('notification-container');
        if (!container) return;

        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        container.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'slideOut 0.5s forwards';
            notification.addEventListener('animationend', () => notification.remove());
        }, duration);
    };

    // ====================================================== //
    // ||              MÓDULO: MENÚ HAMBURGUESA            || //
    // ====================================================== //

    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');

    if (hamburger && navMenu) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
            document.body.classList.toggle('menu-open');
        });
    }

    window.addEventListener('resize', () => {
        if (window.innerWidth > 768) {
            if (hamburger && navMenu) {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
                document.body.classList.remove('menu-open');
            }
        }
    });


    // ====================================================== //
    // ||            MÓDULO: MODAL DE AUTENTICACIÓN        || //
    // ====================================================== //

    const modal = document.getElementById('auth-modal');
    let openModal = () => {}; 

    if (modal) {
        const loginBtn = document.getElementById('login-btn');
        const registerBtn = document.getElementById('register-btn');
        const closeBtn = modal.querySelector('.close-btn');
        const loginView = document.getElementById('login-view');
        const registerView = document.getElementById('register-view');
        const requestResetView = document.getElementById('request-reset-view');
        
        const toggleToRegisterLink = document.getElementById('form-toggle-login')?.querySelector('a');
        const toggleToLoginLink = document.getElementById('form-toggle-register')?.querySelector('a');
        const forgotPasswordLink = document.getElementById('forgot-password-link');
        const backToLoginLink = document.getElementById('back-to-login-link')?.querySelector('a');

        const resetAllAuthForms = () => {
            const forms = modal.querySelectorAll('form');
            forms.forEach(form => form.reset());
        };

        openModal = (view = 'login') => {
            modal.style.display = 'flex';
            loginView.style.display = 'none';
            registerView.style.display = 'none';
            if (requestResetView) requestResetView.style.display = 'none';

            if (view === 'register') {
                registerView.style.display = 'block';
            } else if (view === 'request-reset') {
                if (requestResetView) requestResetView.style.display = 'block';
            } else {
                loginView.style.display = 'block';
            }
        };

        const closeModal = () => {
            modal.style.display = 'none';
            resetAllAuthForms();
        };

        if (loginBtn) loginBtn.addEventListener('click', () => openModal('login'));
        if (registerBtn) registerBtn.addEventListener('click', () => openModal('register'));
        if (closeBtn) closeBtn.addEventListener('click', closeModal);
        if (toggleToRegisterLink) toggleToRegisterLink.addEventListener('click', (e) => { e.preventDefault(); openModal('register'); });
        if (toggleToLoginLink) toggleToLoginLink.addEventListener('click', (e) => { e.preventDefault(); openModal('login'); });
        if (forgotPasswordLink) forgotPasswordLink.addEventListener('click', (e) => { e.preventDefault(); openModal('request-reset'); });
        if (backToLoginLink) backToLoginLink.addEventListener('click', (e) => { e.preventDefault(); openModal('login'); });

        modal.addEventListener('click', (event) => {
            if (event.target === modal) {
                closeModal();
            }
        });
    }

    // ====================================================== //
    // ||            MÓDULO: MANEJO DE FORMULARIOS         || //
    // ====================================================== //
    
    async function handleFormSubmit(action, data, onSuccess) {
        try {
            const response = await fetch(`${API_URL}?action=${action}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            const result = await response.json();

            if (response.ok) {
                if (onSuccess) {
                    onSuccess(result);
                }
            } else {
                showNotification(result.message || `Error del servidor: ${response.status}`, 'error');
            }
        } catch (error) {
            console.error('Error en handleFormSubmit:', error);
            showNotification('Error de conexión o del servidor.', 'error');
        }
    }

    // --- Formulario de Registro ---
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const data = {
                email: registerForm.querySelector('input[name="register-email"]').value,
                password: registerForm.querySelector('input[name="register-password"]').value
            };
            handleFormSubmit('register', data, (result) => {
                showNotification(result.message, 'success');
                localStorage.setItem('userEmail', result.data.email);
                updateAuthView();
                if (modal) modal.style.display = 'none';
            });
        });
    }

    // --- Formulario de Login ---
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const data = {
                email: loginForm.querySelector('input[name="login-email"]').value,
                password: loginForm.querySelector('input[name="login-password"]').value
            };
            handleFormSubmit('login', data, (result) => {
                showNotification(result.message, 'success');
                localStorage.setItem('userEmail', result.data.email);
                updateAuthView();
                if (modal) modal.style.display = 'none';
            });
        });
    }

    // --- Formulario de Solicitud de Restablecimiento ---
    const requestResetForm = document.getElementById('request-reset-form');
    if (requestResetForm) {
        requestResetForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const data = {
                email: requestResetForm.querySelector('input[name="reset-email"]').value
            };
            handleFormSubmit('request-reset', data, (result) => {
                if (modal) modal.style.display = 'none';
                
                if (result.data && result.data.token) {
                    showNotification('Redirigiendo a la página de restablecimiento...', 'success', 2000);
                    setTimeout(() => {
                        window.location.href = `reset-password.html?token=${result.data.token}`;
                    }, 2000);
                } else {
                    showNotification(result.message, 'success');
                }
            });
        });
    }

    // --- Formulario para Establecer Nueva Contraseña ---
    const resetPasswordForm = document.getElementById('reset-password-form');
    if (resetPasswordForm) {
        const params = new URLSearchParams(window.location.search);
        const token = params.get('token');
        if (token) {
            document.getElementById('reset-token').value = token;
        } else {
            const resetBox = document.getElementById('reset-box');
            if(resetBox) {
                resetBox.innerHTML = '<h2>Token no válido o ausente</h2><p>Por favor, solicita un nuevo enlace de restablecimiento desde la página de inicio de sesión.</p>';
            }
        }

        resetPasswordForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const data = {
                token: resetPasswordForm.querySelector('#reset-token').value,
                new_password: resetPasswordForm.querySelector('#new-password').value,
                confirm_password: resetPasswordForm.querySelector('#confirm-password').value
            };
            handleFormSubmit('reset-password', data, (result) => {
                showNotification(result.message, 'success');
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 2000);
            });
        });
    }
    
    // --- Formulario de Contacto Principal ---
    const mainContactForm = document.getElementById('main-contact-form');
    if (mainContactForm) {
        mainContactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const data = {
                name: mainContactForm.querySelector('input[name="name"]').value,
                email: mainContactForm.querySelector('input[name="email"]').value,
                message: mainContactForm.querySelector('textarea[name="message"]').value
            };
            handleFormSubmit('contact', data, (result) => {
                showNotification(result.message, 'success');
                mainContactForm.reset();
                updateAuthView();
            });
        });
    }

    // ====================================================== //
    // ||            MÓDULO: PLANES Y PRECIOS              || //
    // ====================================================== //

    const contractButtons = document.querySelectorAll('.btn-contratar');
    contractButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault(); 

            const userEmail = localStorage.getItem('userEmail');
            const plan = button.dataset.plan;

            if (userEmail) {
                if (plan === 'Prueba') {
                    window.location.href = `gracias.html?plan=Prueba`;
                } else {
                    window.location.href = `pago.html?plan=${plan}`;
                }
            } else {
                openModal('login');
                showNotification('Por favor, inicia sesión para contratar un plan.', 'error');
            }
        });
    });

    // ====================================================== //
    // ||            MÓDULO: ESTADO DE AUTENTICACIÓN       || //
    // ====================================================== //

    const loggedOutView = document.getElementById('logged-out-view');
    const loggedInView = document.getElementById('logged-in-view');
    const userEmailDisplay = document.getElementById('user-email-display');
    const logoutBtn = document.getElementById('logout-btn');

    function updateAuthView() {
        const userEmail = localStorage.getItem('userEmail');
        const contactEmailField = document.getElementById('contact-email');

        if (userEmail) {
            if (loggedOutView) loggedOutView.style.display = 'none';
            if (loggedInView) loggedInView.style.display = 'flex';
            if (userEmailDisplay) userEmailDisplay.textContent = userEmail;
            if (contactEmailField) {
                contactEmailField.value = userEmail;
            }
        } else {
            if (loggedOutView) loggedOutView.style.display = 'flex';
            if (loggedInView) loggedInView.style.display = 'none';
            if (contactEmailField) {
                contactEmailField.value = '';
            }
        }
    }

    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            localStorage.removeItem('userEmail');
            showNotification('Has cerrado sesión.', 'success');
            if (modal) {
                const forms = modal.querySelectorAll('form');
                forms.forEach(form => form.reset());
            }
            updateAuthView();
        });
    }

    // ====================================================== //
    // ||                    INICIALIZACIÓN                || //
    // ====================================================== //

    const copyrightYear = document.getElementById('copyright-year');
    if (copyrightYear) {
        copyrightYear.textContent = new Date().getFullYear();
    }

    updateAuthView();
});
