"use strict";

document.addEventListener('DOMContentLoaded', () => {
    // --- OBTENER PARÁMETROS DE LA URL ---
    const params = new URLSearchParams(window.location.search);
    const plan = params.get('plan');

    // --- REFERENCIAS A ELEMENTOS DEL DOM ---
    const titleElement = document.getElementById('thank-you-title');
    const messageElement = document.getElementById('thank-you-message');
    const ctaButton = document.getElementById('thank-you-cta');
    const downloadButton = document.getElementById('download-btn'); 

    if (!titleElement || !messageElement || !ctaButton) {
        console.error("No se encontraron los elementos necesarios en la página de agradecimiento.");
        return;
    }

    // --- PERSONALIZAR MENSAJE SEGÚN EL PLAN CONTRATADO ---
    if (plan === 'Prueba') {
        titleElement.innerHTML = `¡<span class="neon-green">Prueba gratuita</span> activada!`;
        messageElement.textContent = 'Has iniciado tu prueba de 7 días. Explora todas las funciones de Ojo Digital y descubre la seguridad inteligente.';
        ctaButton.textContent = 'Ir al Inicio';
        ctaButton.href = 'index.html';
    } else if (plan && plan !== 'Desconocido') {
        titleElement.innerHTML = `¡<span class="neon-green">Gracias</span> por tu compra!`;
        messageElement.textContent = `Hemos procesado tu pago del plan "${plan}". Ya puedes empezar a proteger lo que más importa.`;
        ctaButton.textContent = 'Volver al Inicio';
        ctaButton.href = 'index.html';
    } else {
        titleElement.innerHTML = `¡Operación <span class="neon-green">Completada</span>!`;
        messageElement.textContent = 'Tu solicitud ha sido procesada exitosamente. ¡Gracias por confiar en Ojo Digital!';
        ctaButton.textContent = 'Volver al Inicio';
        ctaButton.href = 'index.html';
    }

    /**
     * --- ARREGLO: Previene el comportamiento por defecto del botón "Descargar" ---
     * Esto evita que la página salte a la parte superior al hacer clic.
     */
    if (downloadButton) {
        downloadButton.addEventListener('click', (e) => {
            e.preventDefault();
        });
    }
});
